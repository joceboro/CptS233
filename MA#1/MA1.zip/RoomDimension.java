public class RoomDimension {

   double width;
   double length;
   
   public RoomDimension() {
   }
   
   //Calculate the area of the room
   double getArea() {
      return(length * width);
   }
}